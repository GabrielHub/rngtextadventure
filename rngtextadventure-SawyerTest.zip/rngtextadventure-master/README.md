# rngtextadventure

A text adventure game with random events

Modified based on a tutorial from https://gdpalace.wordpress.com/2017/09/12/text-adventure/ 